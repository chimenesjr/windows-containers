﻿using System;
using System.Web;

namespace aspx
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
        }
    }
}