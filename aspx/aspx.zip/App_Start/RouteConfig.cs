using System.Web.Routing;

namespace aspx
{
    public static class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {

        }
    }
}
